<div id="footer">
            B&W 1.5 Copyright &copy 2014. All rights reserved to <a href="#">B&W</a>
        </div>
       
</body>
</html>