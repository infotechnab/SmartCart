<div id="contentBackground">
    <div id='contentWrapper'>

        <div id="cart_detail">
            <div id="checkOutForm">
                <table>
                    <tr>
                        <td height='50px'>Delivery Details</td>
                    </tr>
                    <tr><td><input type='text' placeholder="Username" class='txtstyle'></td></tr>
                    <tr><td><input type='text' placeholder="Delivery Address" class='txtstyle'></td></tr>
                    <tr><td><input type='text' placeholder="City" class='txtstyle'></td></tr>
                    <tr><td><input type='text' placeholder="State" class='txtstyle'></td></tr>
                    <tr><td><input type='text' placeholder="Zip" class='txtstyle'></td></tr>
                    <tr><td><input type='button' value="Check Out" class='updateBtnStyle'></td></tr>
                </table>
            </div>
        </div>
    </div>
</div>