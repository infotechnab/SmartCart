<div class="updateBtnStyle" style=" padding: 12px; width: 252px; background:black; text-align: center; margin: 0 auto 0 auto;">
    <?php echo anchor('view/registeruser', 'Continue') ?>
</div>