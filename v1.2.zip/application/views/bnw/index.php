        
        <div class="rightSide">
            <h2>Dashboard</h2> 
            <hr class="hr-gradient"/>
            <p>Welcome to dashboard of <b> B&W </b>. All the Pages, Posts, Activities, News, Albums, Download files and Results can be managed through this dashboard.
            User Actions like adding, editing and deleting contents are easy to do.
            </p>
            <p>
                This dashboard has been maintained by <a href="http://www.salyani.com.np">Salyani Technologies (P) Ltd.</a>.<br/>
                For more details and support please contact <a href="http://www.salyani.com.np" target="_blank">Salyani Technologies</a>. 
            </p>
        </div>
        <div class="clear"></div>
        
    
        
        
        
    </div>
    
    
    
   
       
