<div class="redColouredDiv" id="navigation">
    <div id="navigationLeft">
        <div id="cssmenu">
            <ul>
                <?php

            $this->load->helper('menumaker');

            fetch_menu (query(0));

        ?>
            </ul>
        </div>
                       
    </div>
                          <div id='searchbox'>
                                <script>
  (function() {
    var cx = '003019572812212623629:aeqqttf4rtk';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
</script>
<style>
    .gsc-search-box td.gsc-search-button
    {
        display: none;
    }
    
    .cse .gsc-control-cse, .gsc-control-cse {
    padding: 0px;
    margin: 0px;
    width: 99%;
    max-height: 15px;
}
.gsc-control-wrapper-cse{
    width: 140%;
    margin: -2px 0px 0px -2px;
}
</style>
<gcse:search></gcse:search>

                          </div>
                        
                    </div>
                    <div class="clear"></div>
                </div> 

            </div>
            
            
            
 <div id="contentBackground">
    <div id='contentWrapper'>
        
            
