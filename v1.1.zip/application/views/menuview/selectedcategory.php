<?php foreach ($selectedcategoryquery as $category) {
                    ?>
                    <div class="container">
                        <div class="containerHeader">
                            <h3> <?php echo $category->category_name ; ?> </h3>
                            
                        </div>
                        <div class="content">

                           <!-- <p class="paragraph"><?php echo $page->page_content; ?></p>    -->    
                        </div>
                                            
  
                <?php } ?>                      
   
                     
                 
                        
      
                        
                        
                        
                        
                        
                        
                    </div> 

                
            </div>

            <div class="clear"></div>
            <!class full is closed here>